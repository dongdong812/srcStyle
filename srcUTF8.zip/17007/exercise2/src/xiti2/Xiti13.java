package xiti2;

public class Xiti13 {

    public static void main(String[] args) {
        String a="Hello";
        String b="Hello";
        String c=new String(a);
        System.out.println(a==b);
        System.out.println(a==c);

    }

}
