package xiti2;

public class xiti1 {

    public static void main(String[] args) {
        System.out.println("teaching\\java2017\\test.txt");
        System.out.println('w'-'a');
        System.out.println("Java"+1+2+3);

    }

}
