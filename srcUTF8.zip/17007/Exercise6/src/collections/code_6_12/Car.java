package collections.code_6_12;

public class Car implements Comparable<Car>{
    private String licenceNumber;
    private Byte weight;
    public Car(String licenceNumber,int weight) {
        this.licenceNumber=licenceNumber;
        this.weight=(byte) weight;
    }
    public int compareTo(Car t)
    {
        return this.weight.compareTo(t.weight);
    }
    public String toString() {
        return "Car ["+licenceNumber+","+weight+"]";
    }

}
