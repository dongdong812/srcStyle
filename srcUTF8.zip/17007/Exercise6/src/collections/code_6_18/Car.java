package collections.code_6_18;

public class Car {
    private String licencenumber;
    private Byte weight;
    public Car(String licencenumber, int weight) {
        super();
        this.licencenumber = licencenumber;
        this.weight = (byte) weight;
    }
    @Override
    public String toString() {
        return "Car [licencenumber=" + licencenumber + ", weight=" + weight + "]";
    }
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((licencenumber == null) ? 0 : licencenumber.hashCode());
        result = prime * result + ((weight == null) ? 0 : weight.hashCode());
        return result;
    }
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        Car other = (Car) obj;
        if (licencenumber == null) {
            if (other.licencenumber != null)
                return false;
        } else if (!licencenumber.equals(other.licencenumber))
            return false;
        if (weight == null) {
            if (other.weight != null)
                return false;
        } else if (!weight.equals(other.weight))
            return false;
        return true;
    }
    

}
