package collections.code_6_23;

public class ArrayStack <E> implements Stack<E>{
    private E [] theArray;
    private int topOfStack;
    private static final int max=128;
    public ArrayStack() {
        theArray=(E[]) new Object[max];
        topOfStack=-1;
    }

    @Override
    public void push(E e) throws RuntimeException {
        if(this.isFull())
            throw new RuntimeException("ArrayStack is already full");
        else
            theArray[++topOfStack]=(E)e;
        
    }

    @Override
    public E pop() throws Exception {
        if(this.isEmpty())
            throw new RuntimeException("ArrayStack is already empty");
        else
            return theArray[topOfStack--];
    }

    private boolean isFull() {
        return topOfStack+1==theArray.length;
    }

    @Override
    public E top() throws Exception {
        if(this.isEmpty())
            throw new RuntimeException("ArrayStack is empty now.");
        else
            return theArray[topOfStack];
    }

    @Override
    public boolean isEmpty() {
        return topOfStack==-1;
    }

    @Override
    public void clear() {
        topOfStack=-1;
        
    }

    

}
