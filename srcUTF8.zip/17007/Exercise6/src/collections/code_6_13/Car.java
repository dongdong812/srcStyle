package collections.code_6_13;

public class Car implements Comparable<Car>{
    private String licenceNumber;
    private Byte weight;
    public Car(String licenceNumber,int weight) {
        this.licenceNumber=licenceNumber;
        this.weight=(byte) weight;
    }
    public int compareTo(Car t)
    {
        return this.weight.compareTo(t.weight);
    }
    public String toString() {
        return "Car ["+licenceNumber+","+weight+"]";
    }
    public int hashCode() {
        final int prime=31;
        int result=1;
        result=prime*result+((weight==null)?0:weight.hashCode());
        return result;
    }
    public boolean equals(Object obj) {
        if(this==obj)
            return true;
        if(obj==null)
            return false;
        if(getClass()!=obj.getClass())
            return false;
        Car other=(Car) obj;
        if(weight==null)
        {
            if(other.weight!=null)
                return false;
        }
        else if(!weight.equals(other.weight))
            return false;
        return true;
        }

}
