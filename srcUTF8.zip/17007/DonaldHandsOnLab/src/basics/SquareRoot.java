package basics;

public class SquareRoot {

    public static void main(String[] args) {
        double c = Double.parseDouble(args[0]);
        System.out.println(squareRoot(c));
    }
    static double squareRoot(double c) {
        double epsilon = 1e-15;
        double estimate = c;
        while(Math.abs(estimate - c/estimate)>epsilon*estimate) {
            estimate = (estimate + c/estimate)/2.0;
        }
        return estimate;
    }

}
