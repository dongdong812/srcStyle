package objects.code_3_4;

public class Test {

    public static void main(String[] args) {
        Car a=new Car();
        double ans=a.area();
        System.out.println(ans);
    }

}
