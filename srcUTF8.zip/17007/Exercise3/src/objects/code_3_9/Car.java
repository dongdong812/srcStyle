package objects.code_3_9;

public class Car {
    private double width,length;
    private Point currentLocation;
    public Car() {
        this(0,0);
    }
        public Car(double width,double length) {
            this.width=width;
            this.length=length;
            
        }
        public double area() {
            return width * length;
        }
        public void setLocation(Point p) {
            currentLocation=p;
        }
        public void setLocation(int x,int y) {
            Point p=new Point(x,y);
            currentLocation=p;
        }
        
}


