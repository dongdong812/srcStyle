package object.code_3_12;

public class ArrayAsPara {

    public static void main(String[] args) {
        int [] a= {2,3};
        swap(a[0],a[1]);
        System.out.println(a[0]+" "+a[1]);
        exchange(a);
        System.out.print(a[0]+" " +a[1]);
        

    }

     static void exchange(int[] a) {
        int temp=a[0];
        a[0]=a[1];
        a[1]=temp;
        
    }

     static void swap(int i, int j) {
        int temp=i;
        i=j;
        j=temp;
        
    }

}
