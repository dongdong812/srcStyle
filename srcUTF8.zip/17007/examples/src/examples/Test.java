package examples;

public class Test {

    public static void main(String[] args) {
          Calculator c=new Calculator();
          c.setA(10);
          c.setB(2);
          int result=c.add();
          int ans=c.minus();
          System.out.println(result);
          System.out.println(ans);
    }

}
