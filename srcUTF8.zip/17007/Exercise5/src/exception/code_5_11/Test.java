package exception.code_5_11;

public class Test {

    public static void main(String[] args) {
        try {
            methodA();
        }catch(ArithmeticException e) {
            System.out.println("Main:"+e.getMessage());
        }

    }
    static void methodA() {
        try {
            methodB();
        }catch(NullPointerException e) {
            System.out.println("methodA:"+e.getMessage());
        }
    }
    static void methodB() {
        methodC();
    }
    static void methodC() {
        int i=1;
        i=2/0;
    }

}
