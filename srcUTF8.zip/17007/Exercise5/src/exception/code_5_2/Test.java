package exception.code_5_2;

import java.util.Scanner;

public class Test {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter an integer: ");
        int n=sc.nextInt();
        System.out.println("Your number is : "+n);

    }

}
