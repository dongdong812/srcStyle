package exception.code_5_6;

public class ExceptionTest {

    public static void main(String[] args) {
        System.out.println(getPassword());
    }

}
