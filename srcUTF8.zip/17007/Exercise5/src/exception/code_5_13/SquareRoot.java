package exception.code_5_13;

import java.io.IOException;

public class SquareRoot {

    public static void main(String[] args) {
        // TODO Auto-generated method stub
        double c=-4;
        try {
            System.out.println(squareroot(c));
        }catch(OutOfRangeException e) {
            System.out.println(e.getMessage()+e.getParameter());
        }

    }
    static double squareroot(double c)throws OutOfRangeException{
        final double ep=1e-15;
        if(c<0) {
            throw new OutOfRangeException("负数不能求平方根: ",c);
        }
        double es=c;
        while(Math.abs(es-c/es)>ep*es) {
            es=(es+c/es)/2.0;
            
        }
        return es;
    }

}
