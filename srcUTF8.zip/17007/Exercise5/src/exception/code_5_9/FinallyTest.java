package exception.code_5_9;

import java.io.IOException;
import java.io.PrintWriter;

public class FinallyTest {

    public static void main(String[] args) {
        // TODO Auto-generated method stub
        PrintWriter output=null;
        try {
            output=new PrintWriter("test.txt");
            output.println("Finally block test.");
        }catch(IOException e) {
            System.out.println(e.getMessage());
            System.exit(0);
        }finally {
            if(output!=null) {
                output.close();
            }
        }

    }

}
