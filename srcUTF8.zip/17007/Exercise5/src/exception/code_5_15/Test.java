package exception.code_5_15;

import java.util.Stack;

public class Test {

    public static void main(String[] args) {
        // TODO Auto-generated method stub
        Stack s=new Stack();
        Object item;
        try {
            item=s.pop();
        }catch (Exception e) {
            System.out.println(e.getMessage());
        }

    }

}
