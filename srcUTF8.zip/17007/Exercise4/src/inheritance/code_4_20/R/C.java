package inheritance.code_4_20.R;

import inheritance.code_4_20.Q.A;

class C extends A{
    void accessAbySubClass() {
        System.out.println("Access the member of A by subclass B in the same package:");
        publicMember();
        protectedMember();
        //defaultMember();
        //privateMember();
    }

}
