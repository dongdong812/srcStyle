package inheritance.code_4_4;

public class test {

    public static void main(String[] args) {
        Car c=new Car("123",2,3);
        String s=c.licenceNumber;
        System.out.println(s);

    }

}
