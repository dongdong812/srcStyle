package inheritance.code_4_16;
abstract class Vehicle{
    abstract public void horn();
}
class Car extends Vehicle{
    public void horn() {
        System.out.println("didi");
    }
}
class FireTruck extends Vehicle{
    public void horn() {
        System.out.println("wu......");
    }
}
class Ambulance extends Vehicle{
    public void horn() {
        System.out.println("didudidu");
    }
}
public class PolyDemo {

    public static void main(String[] args) {
        Vehicle a,b,c;
        a=new Car();
        b=new FireTruck();
        c=new Ambulance();
        a.horn();
        b.horn();
        c.horn();

    }

}
