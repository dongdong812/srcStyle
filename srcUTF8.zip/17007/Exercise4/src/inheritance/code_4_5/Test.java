package inheritance.code_4_5;

public class Test {

    public static void main (String[] args) {
        Child c=new Child();
    }
}
