package inheritance.code_4_8;

public class Car extends Vehicle {
    public void horn() {
        System.out.println("嘀嘀");
    }

}
