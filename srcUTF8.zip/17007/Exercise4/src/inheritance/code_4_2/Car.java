package inheritance.code_4_2;

public class Car extends Vehicle {
    private double width,length;        //车身长度和宽度    
    
    public Car() {
        this(0, 0);
    }
    public Car(double width,double length) {
        this.width=width;
        this.length=length;
    }
    
    public double area() {
        return width*length;
    }
    
}
