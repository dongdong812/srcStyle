package inheritance.code_4_2;

public class Test {

    public static void main(String[] args) {
        Car c=new Car();
        c.setLicenceNumber("12345");
        String s=c.licenceNumber;
        System.out.println(s);
    }

}
