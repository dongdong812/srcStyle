package inheritance.code_4_10;

public interface Stack {
    boolean push(Object e);
    boolean pop();
    Object top();
    boolean isEmpty();
    boolean isFull();
    void clean();
}
