package inheritance.code_4_10;

public class test {

    public static void main(String[] args) {
        Stack s1=new ListStack();
        s1.push("123");
        System.out.println(s1.top());

    }

}
