package inheritance.code_4_17;
interface Speakable{
    void speak();
}

class Dog implements Speakable{
    public void speak() {
        System.out.println("汪汪");
    }
}

class Cat implements Speakable{
    public void speak() {
        System.out.println("喵喵");
    }
}



public class Test {

    public static void main(String[] args) {
        Speakable a,b;
        a=new Dog();
        b=new Cat();
        a.speak();
        b.speak();

    }

}
