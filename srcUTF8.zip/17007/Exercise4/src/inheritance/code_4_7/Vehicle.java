package inheritance.code_4_7;

public class Vehicle {
    String licenceNumber;
    double width;
    
    public String getLicenNumber() {
        return licenceNumber;
    }
    
    public void setLicenceLicenceNumber(String licenceNumber) {
        this.licenceNumber=licenceNumber;
    }
    
    public double area() {
        return 0;
    }

}
