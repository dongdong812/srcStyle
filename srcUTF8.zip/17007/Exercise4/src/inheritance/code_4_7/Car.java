package inheritance.code_4_7;

public class Car extends Vehicle {
    double width, length;
    
    public Car() {
        this(0,0);
    }
    
    public Car(double width,double length) {
        this.length=length;
        this.width=width;
    }
    
    public double area() {
        return width*length;
    }

}
