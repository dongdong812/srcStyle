package basics;

public class Calculator {
    int a,b,c;
    public  Calculator(int x,int y,int z){
        a=x;
        b=y;
        c=z;
    }
    public void sort() {
        int temp;
        if(a>b) {
            temp=a;
            a=b;
            b=temp;
        }
        if(a>c) {
            temp=a;
            a=c;
            c=temp;
        }
        if (b>c) {
            temp=a;
            a=b;
            b=temp;
        }
    }
    public String toString() {
        return "Calculator [a="+a+",b="+b+",c="+c+"]";
    }
}
