package collections.code_6_10;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
public class CollectionsFill {

    public static void main(String[] args) {
        List<String>list=new ArrayList<String>();
        for(int i=0;i<10;i++) {
            list.add(""+i);
        }
        System.out.println(list);
        Collections.fill(list, "Java");
        System.out.println(list);

    }

}
