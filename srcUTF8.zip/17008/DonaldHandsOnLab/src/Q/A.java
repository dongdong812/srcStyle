package Q;

public class A {
    public void publicMember() {
        System.out.println("I am a public member in A.");
    }
    protected void protectedMember() {
        System.out.println("I am a protected member in A.");
    }
    void defaultMember() {
        System.out.println("I am a default member in A.");
    }
    public void privateMember() {
        System.out.println("I am a private member in A.");
    }
     void accessAinClass() {
        System.out.println("Access the member in the same class.");
        publicMember();
        protectedMember();
        defaultMember();
        privateMember();

    }
   
}
