package P;
import Q.A;
public class B {
    void accessAbyOtherClass() {
        A a=new A();
        System.out.println("Accessed by other class in another package:");
        a.publicMember();
        a.protectedMember();
        a.defaultMember();
        a.privateMember();
        
    }

}
