package collections.code_6_4;

public class Car {
    private String licenceNumber;
    private int weight;
    public Car(String licenceNumber,int weight) {
        super();
        this.licenceNumber=licenceNumber;
        this.weight=weight;
    }
    public int hashCode() {
        final int prime=31;
        int result=1;
        result=prime*result
                +((licenceNumber==null)?0:licenceNumber.hashCode());
        result=prime*result+weight;
        return result;
    }
    public boolean equals(Object obj) {
        if(this==obj)
            return true;
        if(obj==null)
            return false;
        if(getClass()!=obj.getClass())
            return false;
        Car other=(Car) obj;
        if(licenceNumber==null) {
            if(other.licenceNumber!=null)
                return false;
        }else if (!licenceNumber.equals(other.licenceNumber))
            return false;
        if(weight!=other.weight)
            return false;
        return true;
    }
}
