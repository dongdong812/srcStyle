package collections.code_6_22;

import java.util.List;
import java.util.ArrayList;

public class Test {

    public static void main(String[] args) {
        // TODO Auto-generated method stub
        List<Number>list=new ArrayList<Number>();
        list.add(new Integer(12));
        list.add(new Float(3.14));
        for(Number element:list)
            System.out.println(element.intValue());
    }

}
