package collections.code_6_5;

import java.util.Set;
import java.util.HashSet;

import inheritance.code_4_16.Car;

public class CarSetTest {

    public static void main(String[] args) {
        //Set<E>DO Auto-generated method stub
        Set<Car> s=new HashSet<Car>();
        s.add(new Car("812",16000));
        if(!s.add(new Car("812",16000)))
            System.out.println("Failed to add duplicated elements.");
    }

}
