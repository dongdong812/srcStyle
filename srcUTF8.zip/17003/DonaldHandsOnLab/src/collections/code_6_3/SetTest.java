package collections.code_6_3;

import java.util.Set;
import java.util.HashSet;
import java.util.Iterator;

public class SetTest {
    public static void main(String[] args) {
        Set<String>h=new HashSet<String>();
        System.out.println("Is the set empty?"+h.isEmpty());
        h.add("A");
        h.add("B");
        h.add("C");
        h.add("D");
        h.add("E");
        h.add(null);
        h.add("B");
        h.add(null);
        System.out.println("The number of elements in the set:"+h.size());
        System.out.println(h);
        System.out.println("Dose the set contain null?"+h.contains(null));
        System.out.println("Is null removed?"+h.remove(null));
        System.out.println(h);
        Iterator<String> iter=h.iterator();
        while(iter.hasNext()) {
            System.out.print(iter.next());
        }
        System.out.println();
        for(String e:h) {
            System.out.print(e);
        }
        System.out.println();
        h.clear();
        System.out.println("Is the set cleared?"+h.isEmpty());
    }
}
