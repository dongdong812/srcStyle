package collections.code_6_9;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class Redundancy {

    public static void main(String[] args) {
        // TODO Auto-generated method stub
        Integer[] a= {1,1,2,3,3,3};
        List<Integer>list=Arrays.asList(a);
        Set<Integer>set=new HashSet<Integer>();
        
        for(Integer item:list) {
            set.add(item);
        }
        
        System.out.println(set);
    }

}
