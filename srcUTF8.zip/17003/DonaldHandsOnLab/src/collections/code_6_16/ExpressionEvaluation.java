package collections.code_6_16;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.StringTokenizer;

public class ExpressionEvaluation {
    public static void main(String[] args) {
        String expression = " ( 1+ ( ( 3 - 2 ) * ( 4 - 1 ) ) ) ";
        Deque<String>operators=new ArrayDeque<String>();
        Deque<Integer>operands=new ArrayDeque<Integer>();
        String token,operator;
        int operand;
        StringTokenizer st=new StringTokenizer(expression);
        while(st.hasMoreTokens()) {
            token = st.nextToken();
            if(token.equals("("))
                ;
            else if(token.equals("+"))
                operators.push(token);
            else if(token.equals("-"))
                operators.push(token);
            else if(token.equals("*"))
                operators.push(token);
            else if(token.equals("/"))
                operators.push(token);
            else if(token.equals(")")) {
                operator = operators.pop();
                operand = operands.pop();
                if(operator.equals("+"))
                    operand = operands.pop()+operand;
                else if(operator.equals("-"))
                    operand = operands.pop()-operand;
                else if(operator.equals("*"))
                    operand = operands.pop()*operand;
                else if(operator.equals("/"))
                    operand = operands.pop()/operand;
                operands.push(operand);
            }else 
                operands.push(Integer.parseInt(token));
        }
        System.out.println(operands.pop());
    }
}
