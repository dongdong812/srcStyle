package inheritance.code_4_4;

public class Car extends Vehicle{
        double width,length;
        public Car(String licenceNumber,double width,double length) {
            super(licenceNumber);
            this.width=width;
            this.length=length;
        }
}
