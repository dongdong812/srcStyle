package inheritance.code_4_4;

public class Test {
    public static void main(String[] args) {
        Car c=new Car("12345",3.0,4.0);
        System.out.println(c.licenceNumber);
        System.out.println(c.width+""+c.length);
    }
}
