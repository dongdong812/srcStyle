package inheritance.code_4_8;

public  abstract class Vehicle {
    abstract public void horn();
}
