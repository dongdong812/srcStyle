package inheritance.code_4_5;

class Ancestor {
    Ancestor(){
        System.out.println("Ancestor.");
    }
}
class Parent extends Ancestor{
    Parent(){
        System.out.println("parent.");
    }
}
public class Child extends Parent{
    Child(){
        System.out.println("Child.");
    }
    public static void main(String[] args) {
        @SuppressWarnings("unused")
        Child c=new Child();
    }
}
