package inheritance.code_4_20.P;
import inheritance.code_4_20.Q.A;
public class B {
    public void accessAbyOtherClass() {
        A a=new A();
        System.out.println("Accessed by other class in the same package:");
        a.publicMember();
        //a.protectedMember();
        //a.defaultMember();
        //a.privateMember();
    }
}
