package inheritance.code_4_20;
import inheritance.code_4_20.P.B;
import inheritance.code_4_20.Q.A;
import inheritance.code_4_20.R.C;
public class Test {
    public static void main(String[] args) {
        A a=new A();
        a.accessAinClass();
        B b=new B();
        b.accessAbyOtherClass();
        C c=new C();
        c.accessAbySubClass();
    }
}
