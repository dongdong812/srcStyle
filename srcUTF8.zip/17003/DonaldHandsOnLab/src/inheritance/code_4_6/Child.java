package inheritance.code_4_6;

public class Child extends Parent{
    public static void staticMethodA() {
        System.out.println("The static Method A in Child.");
    }
    public void instanceMethodA() {
        System.out.println("The instance method A in Child.");
    }
}
