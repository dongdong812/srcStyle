package inheritance.code_4_6;

public class Parent {
    public static void staticMethodA() {
        System.out.println("The static method A in Parent.");
    }
    public static void staticMethodB() {
        staticMethodA();
    }
    public void instanceMethodA() {
        System.out.println("The instance method A in Parent.");
    }
    public void instanceMethodB() {
        instanceMethodA();
    }
}
