package inheritance.code_4_16;

public class PolyDemo {
    public static void main (String[] args) {
        Car a;
        FireTruck b;
        Ambulance c;
        a=new Car(null, 0);
        b=new FireTruck();
        c=new Ambulance();
        a.horn();
        b.horn();
        c.horn();
    }
}