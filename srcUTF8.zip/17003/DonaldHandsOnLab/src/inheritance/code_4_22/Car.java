package inheritance.code_4_22;

import objects.code_3_9.Point;

public class Car implements Cloneable{
    private double width,length;
    private Point currentLocation;
    public  Car() {
        this(0,0);
        currentLocation=new Point (0,0);
    }
    public Car (double width,double length) {
        this.width=width;
        this.length=length;
        currentLocation=new Point(0,0);
    }
    public Car clone() {
        Car cloned=null;
        try {
            cloned=(Car) super.clone();
        }catch (CloneNotSupportedException e) {
            System.err.println("Car object can't be cloned.");
            return null;
        }
        return cloned;
    }
    public String toString() {
        return"[width="+width+",length="+length+",Location="+currentLocation+"]";
    }
    public void setLocation(Point p) {
        currentLocation.setXY(p.getX(),p.getY());
    }
    public void setLocation(int x,int y) {
        currentLocation.setXY(x, y);
    }
}
