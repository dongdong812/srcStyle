package inheritance.code_4_17;

public class Cat implements Speakable{
    public void speak() {
        System.out.println("喵喵");
    }
}
