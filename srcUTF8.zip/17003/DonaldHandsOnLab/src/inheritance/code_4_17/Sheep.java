package inheritance.code_4_17;

public class Sheep implements Speakable{
    public void speak() {
    System.out.println("咩咩");
    }
}
