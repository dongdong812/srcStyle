package inheritance.code_4_17;

public class Test {
    public static void main(String [] args) {
        Speakable a,b,c;
        a=new Dog();
        b=new Cat();
        c=new Sheep();
        a.speak();
        b.speak();
        c.speak();
    }
}
