package inheritance.code_4_7;

public class Car extends Vehicle{
    double width,length;
    public Car() {
        this(0,0);
    }
    public Car(double width,double length) {
        this.width=width;
        this.length=length;
    }
    public double area() {
        return width*length;
    }
}
