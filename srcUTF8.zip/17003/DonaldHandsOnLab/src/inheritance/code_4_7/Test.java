package inheritance.code_4_7;

public class Test {
    public static void main(String[] args) {
        Car c=new Car(2.0,3.0);
        @SuppressWarnings("unused")
        double x=c.width;
        Vehicle v=c;
        x=v.width;
        @SuppressWarnings("unused")
        double y=v.area();
    }
}
