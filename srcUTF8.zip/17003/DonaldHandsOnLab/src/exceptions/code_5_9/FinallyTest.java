package exceptions.code_5_9;

import java.io.IOException;
import java.io.PrintWriter;

public class FinallyTest {
    public static void main(String[] args) {
        PrintWriter outPut=null;
        try {
            outPut=new PrintWriter("test.txt");
            outPut.println("Finally block test.");
        }catch(IOException e) {
            System.out.println(e.getMessage());
        }finally {
            if(outPut!=null) {
                outPut.close();
            }
        }
    }
}
