package exceptions.code_5_15;

import java.util.Stack;

public class A {

    public static void main(String[] args) {
        // TODO Auto-generated method stub
        @SuppressWarnings("rawtypes")
        Stack s=new Stack();
        @SuppressWarnings("unused")
        Object item;
        try {
            item=s.pop();
        }catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

}
