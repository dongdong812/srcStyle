package exceptions.code_5_11;


public class Test {
    public static void main(String[] args) {
        try {
            methodA();
        }
        catch(ArithmeticException e) {
            System.out.println("Main:"+e.getMessage());
            System.exit(1);
        }
    }
    static void methodA() {
        try {
            methodB();
        }catch(NullPointerException e) {
            System.out.println("methodA:"+e.getMessage());
            System.exit(1);
        }
    }
    static void methodB() {
        methodC();
    }
    static void methodC() {
        @SuppressWarnings("unused")
        int i=1;
        i=2/0;
    }
}
