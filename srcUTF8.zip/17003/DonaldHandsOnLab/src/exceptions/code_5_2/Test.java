package exceptions.code_5_2;

import java.util.Scanner;

public class Test {

    public static void main(String[] args) {
        // TODO Auto-generated method stub
        @SuppressWarnings("resource")
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter an integer:");
        int n=sc.nextInt();
        System.out.println("Your number is:"+n);
    }
}
