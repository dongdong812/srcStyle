package exceptions.code_5_4;

import java.io.File;
import java.util.Scanner;

public class ExampleThrows_1 {
    public String getNextLine(){
        @SuppressWarnings("resource")
        Scanner sc=new Scanner(new File("D:\\java\\test.txt"));
        return sc.nextLine();
    }
}
