package objects.code_3_18;

public class ScopeOfVariable {
    static int x=100;
    public static void main(String args[]) {
        int i;
        for(i=0;i<3;i++) {
            int x=0;
            x=x+10;
            System.out.println("x in the for loop:"+x);
        }
        System.out.println("i is now;"+i);
        System.out.println("x in the class;"+x);
    }
    static void aMethod() {
        int x=1;
        System.out.println("x in aMethod:"+x);
    }
}
