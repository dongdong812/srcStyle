package objects.code_3_20;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;

public class AboutClass {
    public static void about(Object object) {
        Class<? extends Object> c=object.getClass();
        System.out.println(c);
        
        @SuppressWarnings("rawtypes")
        Constructor[ ] constructors=c.getConstructors();
        for (@SuppressWarnings("rawtypes") Constructor cs : constructors) {
            String line="c";
            line +=cs.getName()+"(";
            @SuppressWarnings("rawtypes")
            Class[ ] parameterTypes=cs.getParameterTypes();
            for (int i=0;i<parameterTypes.length;i++) {
                line +=parameterTypes[i].getName();
                if(i!=parameterTypes.length-1)
                    line+=",";
            }
            line+=")";
            System.out.println(line);
        }
        Method[] methods=c.getMethods();
        for (Method method:methods) {
            String line="M";
            @SuppressWarnings("rawtypes")
            Class returnType=method.getReturnType();
            line +=returnType.getName()+""+method.getName()+"(";
            @SuppressWarnings("rawtypes")
            Class[ ] parameterTypes=method.getParameterTypes();
            for(int i=0;i<parameterTypes.length;i++) {
                line+=parameterTypes[i].getName();
            if(i!=parameterTypes.length-1)
                line+=",";
            }
            line+=")";
            System.out.println(line);
        }
    }
}
