package basics;

public class CalculatorTest {
    public static void main(String[] args) {
        Calculator calculator=new Calculator(7,3,9);
        calculator .sort();
        System.out.println(calculator);
    }

}
