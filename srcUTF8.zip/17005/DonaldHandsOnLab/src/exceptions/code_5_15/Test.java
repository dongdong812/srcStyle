package exceptions.code_5_15;
import inheritance.code_4_10.ArrayStack;
import inheritance.code_4_10.Stack;
public class Test {
    public static void main(String[] args) {
        Stack s = new ArrayStack();
        Object item;
        try {
            item = s.pop();
        }catch(Exception e) {
            System.out.println(e.getMessage());
        }
    }

}
