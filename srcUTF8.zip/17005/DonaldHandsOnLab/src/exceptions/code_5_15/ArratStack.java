package exceptions.code_5_15;

public class ArratStack {

}
