package exceptions.code_5_2;

import java.util.Scanner;

public class Test {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter an integer:");
        int n = sc.nextInt();     //如果此处抛出异常，则跳过main方法中其余代码，程序终止
        System.out.println("Your number is:"+n);
    }

}
