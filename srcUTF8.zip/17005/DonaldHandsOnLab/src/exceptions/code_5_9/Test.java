package exceptions.code_5_9;

import java.io.File;
import java.io.IOException;
import java.util.Scanner;

public class Test {
    public String getPassword() {
        Scanner sc = null;
        String s = null;
        try {
            sc = new Scanner (new File("D:\\java\\test.txt"));
            s = sc.nextLine();
        }catch(IOException e) {
            System.out.println(e.getMessage());
            //System.exit(1);
        }finally {
            if(sc!=null) {
                sc.close();
            }
        }
        return s;
    }
}
