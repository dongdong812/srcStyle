package exceptions.code_5_10;

import java.io.IOException;
import java.io.PrintWriter;

public class FinallyTest {
    public static void main(String[] args) {
        PrintWriter output = null;
        try{
            output = new PrintWriter("test.txt");
            output.println("Finally block test.");
        }catch(IOException e) {
            System.out.println(e.getMessage());
        }finally {
            if(output!=null) {
                output.close();
            }
        }
    }

}
