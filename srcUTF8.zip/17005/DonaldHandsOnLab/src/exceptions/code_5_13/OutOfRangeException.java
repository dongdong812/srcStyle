package exceptions.code_5_13;

public class OutOfRangeException extends Exception{
    private double parameter;
    public OutOfRangeException(String msg,double parameter) {
        super(msg);
        this.parameter = parameter;
    }
    public double getParameter() {
        return this.parameter;
    }
}
