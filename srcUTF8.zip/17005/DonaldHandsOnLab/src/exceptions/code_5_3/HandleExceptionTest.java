package exceptions.code_5_3;
import java.util.InputMismatchException;
import java.util.Scanner;
public class HandleExceptionTest {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n;
        try {
            System.out.println("Enter an integer:");
            n = sc.nextInt();
        }catch(InputMismatchException e) {
            System.out.println("Incorrect input:An integer is required."+"Default value 0 is used.");
            n=0;
        }
        System.out.println("Your number is: "+n);
    }

}
