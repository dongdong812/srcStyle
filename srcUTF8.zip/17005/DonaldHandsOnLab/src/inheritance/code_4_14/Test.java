package inheritance.code_4_14;

import inheritance.code_4_10.ArrayStack;
import inheritance.code_4_10.Stack;

public class Test {

    public static void main(String[] args) {
        String s = "A(B,C(D,E(F,G)),H);XY(Z);";
        Stack stack = new ArrayStack();
        int N = s.length();
        for (int i = 0; i < N; i++) {
            if (s.charAt(i) == '(')
                stack.push('(');
            if (s.charAt(i) == ')') {
                if (stack.isEmpty()) {
                    System.out.println("Miamatch!");
                    return;
                }
                stack.pop();
            }
        }
        if (stack.isEmpty())
            System.out.println("Match!");
        else
            System.out.println("Mismatch");

    }
}
