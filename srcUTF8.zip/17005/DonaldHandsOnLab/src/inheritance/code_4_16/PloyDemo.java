package inheritance.code_4_16;

public class PloyDemo {

    public static void main(String[] args) {
        Vehicle a, b, c;
        a = new Car();
        b = new FireTruck();
        c = new Ambulance();
        a.horn();
        b.horn();
        c.horn();
    }
}
