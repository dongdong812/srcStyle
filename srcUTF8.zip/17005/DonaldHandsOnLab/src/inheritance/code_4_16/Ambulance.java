package inheritance.code_4_16;

public class Ambulance extends Vehicle {
    public void horn() {
        System.out.println("嘀嘟嘀嘟");
    }
}
