package inheritance.code_4_16;

public class Car extends Vehicle {
    public void horn() {
        System.out.println("嘀嘀");
    }
}
