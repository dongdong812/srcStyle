package inheritance.code_4_22;

public class CloneTest {

    public static void main(String[] args) {
        Car a = new Car(1,2);
        a.setLocation(3, 4);
        Car b = a.clone();
        System.out.println("Car="+a);
        System.out.println("copy="+b);
    }

}
