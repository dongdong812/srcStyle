package inheritance.code_4_23;

public class Point implements Cloneable{
    private int x;
    private int y;
    public Point() {
    }
    public Point (int xValue,int yValue) {
        x=xValue;
        y=yValue;
    }
    public int getX() {
        return x;
    }
    public int getY() {
        return y;
    }
    public void setXY(int x,int y) {
        this.x=x;
        this.y=y;
    }
    public Point clone() {
        Point cloned=null;
        try {
            cloned=(Point)super.clone();
        }catch(CloneNotSupportedException e) {
            System.out.println("Point object can't be cloned.");
            return null;
        }
        return cloned;
    }
        public String toString() {
            return "["+getX()+","+getY()+"]";
        }
    }