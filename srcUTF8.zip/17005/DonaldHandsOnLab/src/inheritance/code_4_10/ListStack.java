package inheritance.code_4_10;

class ListNode {
    public Object element;
    public ListNode nextNode;

    public ListNode(Object element) {
        this(element, null);
    }

    public ListNode(Object element, ListNode nextNode) {
        this.element = element;
        this.nextNode = nextNode;
    }
}

public class ListStack implements Stack {
    private ListNode topOfStack;

    public ListStack() {
        topOfStack = null;
    }

    public boolean push(Object e) {
        if (this.isFull())
            return false;
        else {
            topOfStack = new ListNode(e, topOfStack);
            return true;
        }
    }

    public boolean pop() {
        if (this.isEmpty())
            return false;
        else {
            topOfStack = topOfStack.nextNode;
            return true;
        }
    }

    public Object top() {
        if (isEmpty())
            return null;
        else
            return topOfStack.element;
    }

    public boolean isEmpty() {
        return topOfStack == null;
    }

    public boolean isFull() {
        return true;
    }

    public void clear() {
        topOfStack = null;
    }
}
