package inheritance.code_4_10;

public class InterfaceTest {

    public static void main(String[] args) {
        Stack s1 = new ListStack();
        s1.push("One");
        // System.out.println(s1.pop());
        s1.clear();
        // System.out.println(s1.pop());
        Stack s2 = new ArrayStack();
        s2.push("Two");
        // System.out.println(s2.pop());
        s2.clear();
        // System.out.println(s2.pop());

    }

}
