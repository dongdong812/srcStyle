package inheritance.code_4_8;

public class Test {

    public static void main(String[] args) {
        Car c = new Car();
        c.horn();
        Ambulance a = new Ambulance();
        a.horn();

    }

}
