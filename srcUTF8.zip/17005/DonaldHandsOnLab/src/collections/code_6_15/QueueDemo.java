package collections.code_6_15;

import java.util.LinkedList;
import java.util.Queue;

public class QueueDemo {
    public static void main(String[] args) {
        String client;
        Queue<String>queue = new LinkedList<String>();
        queue.add("张三");
        queue.add("李四");
        queue.add("王五");
        System.out.println(queue);
        client = queue.remove();
        System.out.println(client+"买票。");
        client = queue.remove();
        System.out.println(client+"买票。");
        client = queue.remove();
        System.out.println(client+"买票。");
        System.out.println(queue.isEmpty());
    }

}
