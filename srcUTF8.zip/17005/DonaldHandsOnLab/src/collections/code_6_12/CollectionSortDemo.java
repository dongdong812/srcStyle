package collections.code_6_12;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

class Car implements Comparable<Car> {
    private String licenceNumber;
    private Byte weight;

    public Car(String licenceNumber, int weight) {
        this.licenceNumber = licenceNumber;
        this.weight = (byte) weight;
    }

    public int compareTo(Car t) {
        return this.weight.compareTo(t.weight);
    }

    public String toString() {
        return "Car [" + licenceNumber + "," + weight + "]";
    }
}

public class CollectionSortDemo {

    public static void main(String[] args) {
        Car[] a = { new Car("B12", 18), new Car("A12", 20), new Car("z34", 17), new Car("z34W", 18),
                new Car("12NN", 19), new Car("12N", 20) };
        List<Car> c = Arrays.asList(a);
        System.out.println(c);
        Collections.sort(c);
        System.out.println(c);
        System.out.println(Collections.max(c));
    }

}
