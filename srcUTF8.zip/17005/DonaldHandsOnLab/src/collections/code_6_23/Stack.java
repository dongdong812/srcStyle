package collections.code_6_23;

public interface Stack <E>{
    void push(E e) throws Exception;
    E pop() throws Exception;
    E top() throws Exception;
    boolean isEmpty();
    void clear();
}
