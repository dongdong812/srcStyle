package collections.code_6_21;

import java.util.ArrayList;
import java.util.List;

public class Test {

    public static void main(String[] args) {
        List<Number>list = new ArrayList<Number>();
        list.add(new Integer(12));
        list.add(new Float(3.14));
        System.out.println(list.get(0).intValue());
        System.out.println(list.get(1).intValue());
    }
}
