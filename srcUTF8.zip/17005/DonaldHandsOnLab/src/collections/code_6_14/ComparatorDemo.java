package collections.code_6_14;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class ComparatorDemo {
    public static void main(String[] args) {
        String [] s = {"abc","ABC","ab","1234","xyz"};
        List<String>list=Arrays.asList(s);
        Collections.sort(list,new StringLengthComparator());
        System.out.println(list);
    }

}
