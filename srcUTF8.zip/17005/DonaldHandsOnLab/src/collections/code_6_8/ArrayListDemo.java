package collections.code_6_8;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.ListIterator;

public class ArrayListDemo {

    public static void main(String[] args) {
        String[] items = { "A", "B", "C", "D", "E", null, "F" };
        List<String> a = new ArrayList<String>(Arrays.asList(items));
        System.out.println(a);
        System.out.println("The element at 5: " + a.get(5));
        // 替换元素
        System.out.println("Replace the element at 5 with 'X' : " + a.set(5, "X"));
        System.out.println(a);
        // 插入元素
        System.out.println("Insert 'Y' before 6!");
        a.add(6, "Y");
        System.out.println(a);
        // 删除元素
        System.out.println("Remove the element at 3: " + a.remove(3));
        System.out.println(a);
        // 向后遍历
        ListIterator<String> iter = a.listIterator();
        while (iter.hasNext()) {
            System.out.print(iter.next());
        }
        System.out.println();
        // 向前遍历
        // a.size()返回实际元素个数，以次数为迭代器的初始位置的索引值
        for (ListIterator<String> it = a.listIterator(a.size()); it.hasPrevious();) {
            System.out.print(it.previous());
        }
        System.out.println();
    }

}
