package objects.code_3_9;

public class Car {
    private double width, length;
    private Point currentLocation;

    public Car() {
        this(0, 0);
    }

    public Car(double width, double length) {
        this.width = width;
        this.length = length;
    }

    public double area() {
        return width * length;
    }

    public void setLocation(Point p) {
        setCurrentLocation(p);
    }

    public void setLocation(int x, int y) {
        Point p = new Point(x, y);
        setCurrentLocation(p);
    }

    public Point getCurrentLocation() {
        return currentLocation;
    }

    public void setCurrentLocation(Point currentLocation) {
        this.currentLocation = currentLocation;
    }
}

class Point {
    private int x;
    private int y;

    public Point() {
    }

    public Point(int xValue, int yValue) {
        x = xValue;
        y = yValue;
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public void setXY(int x, int y) {
        this.x = x;
        this.y = y;
    }

    public String toString() {
        return "[" + getX() + "," + getY() + "]";
    }
}