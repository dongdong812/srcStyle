package objects.code_3_14;

public class StaticVariableDemo {
    static int flag;

    public static void main(String[] args) {
        Car a = new Car();
        Car b = new Car();
        a.notify(0);
        System.out.println(flag);
        b.notify(1);
        System.out.println(flag);
    }
}

class Car {
    double width, height;

    public Car() {
        this.width = 3;
        this.height = 4;
    }

    public void notify(int i) {
        StaticVariableDemo.flag = 1;
    }
}
