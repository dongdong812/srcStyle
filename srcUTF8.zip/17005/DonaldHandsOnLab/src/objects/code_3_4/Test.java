package objects.code_3_4;

public class Test {

    public static void main(String[] args) {
        Car a = new Car();
        // Car b = new Car(1.0,2.0);
        a.area();
        // b.area();
        // System.out.println("Width of a:"+a.width);
        // System.out.println("Length of a:"+a.length);
        // System.out.println("The result is:"+a.area());
        // System.out.println("Width of b:"+b.width);
        // System.out.println("Length of b:"+b.length);
        // System.out.println("The result is:"+b.area());
    }

}
