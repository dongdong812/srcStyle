package basics;

import java.util.Scanner;

public class ScannerTest {

    public static void main(String[] args) {
        @SuppressWarnings("resource")
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter an integer,a double value and a string:");
        int x = sc.nextInt();
        double y = sc.nextDouble();
        String s = sc.next();
        System.out.println("Your integer is:" + x);
        System.out.println("Your double value is:" + y);
        System.out.println("Your string is:" + s);

    }

}
