package inheritance.code_4_6;

public class Test {

    public static void main(String[] args) {
        Child c=new Child();
        Child.staticMethodA();
        Child.staticMethodB();
        c.instanceMethodA();
        c.instanceMethodB();// TODO Auto-generated method stub
    }
}
