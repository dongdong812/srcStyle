package inheritance.code_4_4;

public class Vehicle {
    String licenceNumber;
    public Vehicle (String licenceNumber) {
        this.licenceNumber=licenceNumber;
    }
}

