package inheritance.code_4_4;

public class Test {
    public static void main(String[] args) {
        Vehicle v=new Vehicle("12345");
        Car c=new Car("123",2.0,3.0);
        System.out.println(c);
    }
}
