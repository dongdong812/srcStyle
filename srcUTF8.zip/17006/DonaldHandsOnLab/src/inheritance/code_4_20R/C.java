package inheritance.code_4_20R;

import inheritance.code_4_20Q.A;

public class C extends A {
    void accessAbyClass() {
        System.out.println( "Access the members of A by subclass B in the same package:");
        publicMember();
        protectedMember();
        //defaultMember();
        //privateMember();
    }


}
