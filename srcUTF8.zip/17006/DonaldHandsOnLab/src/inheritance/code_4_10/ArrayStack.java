package inheritance.code_4_10;

public class ArrayStack implements Stack{
    private Object[] objectArray;
    private int topOfStack;
    private static final int CAPACITY=128;
    public ArrayStack() {
        objectArray=new Object[CAPACITY];
        topOfStack=-1;
    }
    public boolean push(Object e) {
        if(this.isFull())
            return false;
        else {
            objectArray[++topOfStack]=e;
            return true;
        }
    }
    public boolean pop() {
        if(this.isEmpty())
            return false;
        else {
            topOfStack--;
            return true;
        }
    }
    public Object top() {
        if(this.isEmpty())
            return null;
        else
            return objectArray[topOfStack];
    }
    public boolean isEmpty() {
        return topOfStack==-1;
    }
    public boolean isFull() {
        return(topOfStack+1==objectArray.length);
    }
    public void clear() {
        topOfStack=-1;
    }
}
