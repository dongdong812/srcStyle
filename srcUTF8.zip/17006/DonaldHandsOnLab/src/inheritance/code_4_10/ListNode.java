package inheritance.code_4_10;

public class ListNode {
    public Object element;
    public ListNode nextNode;
    public ListNode (Object element) {
        this(element,null);
    }
    public ListNode (Object element,ListNode nextNode) {
        this.element=element;
        this.nextNode=nextNode;
    }

}
