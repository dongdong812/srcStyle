package inheritance.code_4_19;

public class B {
    void accessAbyOtherClass() {
    A a=new A();
    System.out.println("Accessed by other class in the same package:");
    a.publicMember();
    a.protectedMember();
    a.defaultMember();
    }
}
