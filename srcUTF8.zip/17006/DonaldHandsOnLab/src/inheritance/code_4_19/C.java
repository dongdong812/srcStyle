package inheritance.code_4_19;

public class C extends A{
    void accessAbySubClass() {
        System.out.println("Access the numbers of A by subclass B in the same package:");
        publicMember();
        protectedMember();
        defaultMember();
    }
}
