package inheritance.code_4_19;

public class AccessDemo {

    public static void main(String[] x) {
        A a=new A();
        a.accessInClass();
        B b=new B();
        b.accessAbyOtherClass();
        C c=new C();
        c.accessAbySubClass();// TODO Auto-generated method stub

    }

}
