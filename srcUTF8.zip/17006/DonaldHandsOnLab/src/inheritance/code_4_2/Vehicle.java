package inheritance.code_4_2;

public class Vehicle{
    String licenceNumber;
    public String getLicenceNumber() {
        return licenceNumber;
}
    public void setLicenceNumber(String licenceNumber) {
        this.licenceNumber=licenceNumber;
}
}
