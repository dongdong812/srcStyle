package inheritance.code_4_5;

public class Ancestor {
    Ancestor(){
        System.out.println("Ancestor.");
    }
}
