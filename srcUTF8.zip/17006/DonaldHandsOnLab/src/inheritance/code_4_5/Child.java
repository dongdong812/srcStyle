package inheritance.code_4_5;

public class Child extends Parent{
    Child(){
        System.out.println("Child.");
    }
}
