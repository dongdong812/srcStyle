package inheritance.code_4_5;

public class Parent extends Ancestor {
    Parent(){
        System.out.println("Parent.");
    }
}
