package exceptions.code_5_15;

import java.util.Stack;

import inheritance.code_4_10.ArrayStack;

public class Test {

    public static void main(String[] args) {
        ArrayStack s=new ArrayStack();
        Object item;
        try{
            item=s.pop();// TODO Auto-generated method stub
        }catch(Exception e) {
            System.out.println(e.getMessage());
        }

    }

}
