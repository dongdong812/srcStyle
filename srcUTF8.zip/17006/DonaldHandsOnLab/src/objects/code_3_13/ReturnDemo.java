package objects.code_3_13;

public class ReturnDemo {
    public static void main(String[] args) {
        A a=new A();
        B b1=a.getB ();
        b1.say();
    }
}
class A{
    public B getB() {
        B b=new B();
        return b;
    }
}class B{
    public void say() {
        System.out.println("I am B.");
    }
}
