package objects.code_3_20;

import objects.code_3_9.Car;

public class Tset {
    public static void main (String[] args) {
        Car a=new Car();
        AboutClass.about(a);;
    }
}
