package objects.code_3_9;

public class ParaDemo2 {
    public static void main(String args[]) {
        Car a=new Car(3,6);
    Point aPoint=new Point(10,20);
    a.setLocation(aPoint);
    }
}
