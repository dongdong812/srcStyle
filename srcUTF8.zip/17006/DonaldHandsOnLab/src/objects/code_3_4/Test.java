package objects.code_3_4;

public class Test {
    public static void main(String[] args) {
        Car a=new Car();
        a.area();
    }
}
