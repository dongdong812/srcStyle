package objects.code_3_4;

public class Car {
    double width,length;
    public Car() {
        width=0;
        length=0;
    }
    public Car(double w,double h) {
        width=w;
        length=h;
    }
    public double area() {
        double result=0.0;
        result=width*length;
        return result;
    }
}
