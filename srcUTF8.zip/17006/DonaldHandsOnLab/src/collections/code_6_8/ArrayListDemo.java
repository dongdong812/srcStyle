package collections.code_6_8;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.ListIterator;

public class ArrayListDemo {
    public static void main(String[] args) {
        String[] items= {"A","B","C","D","E",null,"F"};
        List<String> a=new ArrayList<String>(Arrays.asList(items));
        System.out.println(a);
        System.out.println("The element at 5: "+a.get(5));
        System.out.println("Replace the element at 5 with 'X' :"+a.set(5, "X"));
        System.out.println(a);
        System.out.println("Insert 'Y' before 6!");
        a.add(6, "Y");// TODO Auto-generated method stub
        System.out.println(a);
        System.out.println("Remove the element at 3:"+a.remove(3));
        System.out.println(a);
        ListIterator<String> iter=a.listIterator();
        while(iter.hasNext()) {
            System.out.println(iter.next());
        }
        System.out.println();
        for(ListIterator<String> it=a.listIterator(a.size());it.hasPrevious();) {
            System.out.println(it.previous());
        }

    }

}
