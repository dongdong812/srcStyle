package collections.code_6_22;

import java.util.ArrayList;
import java.util.List;

public class Test {

    public static void main(String[] args) {
        List<Number>list=new ArrayList<Number>();
        list.add(new Integer(12));
        list.add(new Float(3.14));
        for(Number element : list)
            System.out.println(element.intValue());// TODO Auto-generated method stub

    }

}
