package collections.code_6_25;

import collections.code_6_23.Stack;
import collections.code_6_24.ArrayStack;

public class Test {

    public static void main(String[] args) {
        Stack<String> s=new ArrayStack<String>();
        try{
            s.push("abc");
            s.push("xyz");
            System.out.println(s.pop());
            System.out.println(s.pop());
            System.out.println(s.pop());// TODO Auto-generated method stub
        }catch (Exception e) {
            System.out.println(e.getMessage());
            System.exit(1);;
        }

    }

}
