package collections.code_6_18;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class HashMapDemo {

    public static void main(String[] args) {
        // TODO Auto-generated method stub
        Car a=new Car("A12",18);
        Car b=new Car("B12",20);
        Car c=new Car("C12",17);
        Car d=new Car("D56",18);
        Car e=new Car("E56",19);
        Car f=new Car("F56",20);
        Car ff=new Car("F56",21);
        Map<String,Car>map=new HashMap<String,Car>();
        map.put("A12",a);
        map.put("B12",b);
        map.put("C12",c);
        map.put("D56",d);
        map.put("E56",e);
        map.put("F56",f);
        map.put("F56",ff);
        System.out.println(map);
        Car s3=map.remove("C12");
        System.out.println(s3+"has been removed.");
        Car s4=map.get("D56");
        System.out.println(map.containsKey("C12")?"C12 is there.":"C12 is not there.");
        System.out.println(map.containsKey(d)?"D56 is there.":"D56 is not there.");
        System.out.println("The number of key-value mappings is"+map.size());
        Set<String>s=map.keySet();
        for(String k:s) {
            Car v=map.get(k);
            System.out.println(k+"->"+v+", ");
        }
        System.out.println();
        map.clear();
        System.out.println(map.isEmpty()?"Map is empty.":"Map is not empty.");
    }

}
class Car{
    private String licenceNumber;
    private Byte weight;
    public Car(String name,int weight) {
        this.licenceNumber=name;
        this.weight=(byte) weight;
    }
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((licenceNumber == null) ? 0 : licenceNumber.hashCode());
        result = prime * result + ((weight == null) ? 0 : weight.hashCode());
        return result;
    }
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        Car other = (Car) obj;
        if (licenceNumber == null) {
            if (other.licenceNumber != null)
                return false;
        } else if (!licenceNumber.equals(other.licenceNumber))
            return false;
        if (weight == null) {
            if (other.weight != null)
                return false;
        } else if (!weight.equals(other.weight))
            return false;
        return true;
    }
    
    
    /*
    @Override
    public String toString() {
        return "Car["+licenceNumber+","+weight+"]";
    }
    @Override
    public int hashCode() {
        final int prime=31;
        int result=1;
        result
    }*/
}
