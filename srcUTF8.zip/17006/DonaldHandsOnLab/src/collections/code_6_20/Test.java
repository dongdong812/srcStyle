package collections.code_6_20;

import java.util.ArrayList;
import java.util.List;

public class Test {

    public static void main(String[] args) {
        List<Integer>list=new ArrayList<Integer>();
        list.add(new Integer(12));
        list.add(new String("abc"));
        System.out.println(list.get(0).intValue());
        System.out.println(list.get(1).intValue());// TODO Auto-generated method stub

    }

}
