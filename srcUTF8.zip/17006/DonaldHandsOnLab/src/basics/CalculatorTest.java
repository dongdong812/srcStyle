package basics;

public class CalculatorTest {

    public static void main(String[] args) {
        // TODO Auto-generated method stub
        Calculator calculator=new Calculator(7,3,9);
        calculator.sort();
        System.out.println(calculator);

    }

}
