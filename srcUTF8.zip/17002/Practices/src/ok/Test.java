package ok;

public class Test {

    public static void main(String[] args) {
       A a=new A("Hello");
       a.doSomething();

    }

}
