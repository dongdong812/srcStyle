package ok;

public class A {
    String s;
    A(String s){
        this.s=s;
    }
    void  doSomething() {
        System.out.println(s);
    }

}
