package forth;

public class Test {

    public static void main(String[] args) {
         A a=new A("");
         a.print();
         
    }

}
