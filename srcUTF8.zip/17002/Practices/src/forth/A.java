package forth;

public class A {
    String s;
    A (String s){
        this.s=s;
    }
void print() {
    System.out.println(s);
}
}
