package fifth;

public class C {
    int i;
    public  C(int j) {
        int i=j;
    }

}
