package fifth;

public class Test {

    public static void main(String[] args) {
         C c=new C(2);

    }

}
