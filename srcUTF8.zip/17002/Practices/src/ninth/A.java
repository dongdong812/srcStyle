package ninth;

public class A {
    int i;
    static int s;
    public A() {
        i++;
        s++;
    }

    public static void main(String[] args) {
        A a=new A();
        A b=new A();
        A c=new A();
        System.out.println("c.i is "+c.i+"c.s is"+c.s);
    }

}
