package third;

public class Test {

    public static void main(String[] args) {
         class A {
             A a;
             String s;
             void dosomething() {
                 System.out.println(s);
             }
         }
 
    }

}
