package objects.code_3_9;

public class ParaDemol {
    public static void main(String arg[]) {
        Car a= new Car(3,6);
        a.setLocation(10,20);
    }
}
