package objects.code_3_12;

public class ArrayAsPara {
    public static void main (String[ ] args) {
        int[]a= {2,3};
        swap(a[0],a[1]);
        exchange(a);
    }
    static void swap(int x,int y) {
        int temp=x;x=y;y=temp;
    }
    static void exchange(int[] p) {
        int temp=p[0];p[0]=p[1];p[1]=temp;
    }

}
