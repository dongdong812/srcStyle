package objects.code_3_20;

import objects.code_3_4.Car;

public class Test {

    public static void main(String[] args) {
         Car a= new Car();
         AboutClass.about(a);
    }

}
