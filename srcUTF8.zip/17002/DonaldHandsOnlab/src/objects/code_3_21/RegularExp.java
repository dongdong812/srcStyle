package objects.code_3_21;

public class RegularExp {

    public static void main(String[] args) {
         String regularExp="[AB]+";
         String inputString="ABBBCA";
         System.out.println(inputString.matches(regularExp));
         inputString="ABBBA";
         System.out.println(inputString.matches(regularExp));

    }

}
