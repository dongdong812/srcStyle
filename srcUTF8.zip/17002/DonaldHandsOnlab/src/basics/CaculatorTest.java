package basics;

public class CaculatorTest {
    public static void main(String[] args) {
            Caculator calculator=new Caculator(7,3,9);
            calculator.sort();
            System.out.println(calculator);
        }
}