package basics;

public class LetterCounter {

    public static void main(String[] args) {
         String paragraph="The JDK include the JRE plus command-line "+
                    "development tools such as compilers and debuggers that are "+
                     "necessary or useful for developing applets and applications.";
                
         int spaces=0,
                letters=0;
             int paragraphLength=paragraph.length();
             for(int i=0;i<paragraphLength;i++) {
                 char ch=paragraph.charAt(i);
            
        if(Character.isLetter( ch )) {
            letters++;
            
        }
        if(Character.isSpaceChar(ch)) {
            spaces++;
        }
    }
System.out.println("The paragraph contains"+letters+"letters and "+spaces+" spaces.\n");
     }
}
