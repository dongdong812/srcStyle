package examples;

public class Calculator {
      int a;
      int b;
      void setA(int x){
      a=x;

     }  
    void setB(int y){
      b=y;

     }
    int add(){
      return a+b;
     }
    int minus(){
      return a-b;
     }
}
