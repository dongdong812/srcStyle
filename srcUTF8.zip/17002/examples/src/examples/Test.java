package examples;
public class Test{
public static void main(String[] args){
    Calculator c=new Calculator();
    c.setA(11);
    c.setB(2);
    int result=c.add();
    System.out.println(result);
  } 
}
