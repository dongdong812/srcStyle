package collections.code_6_19;

import java.util.List;
import java.util.ArrayList;

public class Test {

    public static void main(String[] args) {
        List list = new ArrayList();
        list.add(new Integer(12));
        list.add(new String("abc"));
        System.out.println(((Integer)list.get(0)).intValue());
        System.out.println(((Integer)list.get(1)).intValue());
    }

}
