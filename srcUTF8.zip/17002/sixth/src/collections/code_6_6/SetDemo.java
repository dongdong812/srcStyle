package collections.code_6_6;
import java.util.HashSet;
import java.util.Set;
public class SetDemo {

    public static void main(String[] args) {
        String[]  a= {"A","B","C","D","E"};
        String [] b= {"X","Y","E"};
        Set<String>A=new HashSet<String>();
        Set<String>B=new HashSet<String>();
        for(String e:a) {
            A.add(e);
        }
        for(String e:b)
        {
            B.add(e);
        }
        Set<String>C;
        C=new HashSet<String>(A);
        C.addAll(B);
        System.out.println(C);
        C=new HashSet<String>(A);
        C.retainAll(B);
        System.out.println(C);
        C= new HashSet<String>(A);
        C.removeAll(B);
        System.out.println(C);

}
}
