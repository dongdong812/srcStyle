package collections.code_6_5;

import java.util.HashSet;
import java.util.Set;

import collections.code_6_4.Car;

public class CarSetTest {

    public static void main(String[] args) {
         Set<Car>s=new HashSet<Car>();
         s.add(new Car("812",16000));
         if(!s.add(new Car("812",16000)))
             System.out.println("Failed to add duplicated elements.");
    }

}
