package collections.code_6_24;

import collections.code_6_23.Stack;

public  class ArrayStack<E> implements Stack<E> {
    private E[] theArray;
    private int topOfStack;
    private static final int DEFAULT_CAPACITY = 128;

    public ArrayStack() {
        theArray = (E[]) new Object[DEFAULT_CAPACITY];
        topOfStack = -1;
    }

    public void push(E e) throws RuntimeException {
        if (this.isFull())
            throw new RuntimeException("ArrayStack is already full.");
        else {
            theArray[++topOfStack] = (E) e;

        }
    }

    public E pop() throws Exception {
        if (this.isEmpty())
            throw new RuntimeException("ArrayStack is already empty.");
        else {
            return theArray[topOfStack--];
        }
    }

    public E top() throws Exception {
        if (this.isEmpty())
            throw new RuntimeException("ArrayStack is empty now.");
        else
            return theArray[topOfStack];
    }

    public boolean isEmpty() {
        return topOfStack == -1;
    }

    public boolean isFull() {
        return (topOfStack + 1 == theArray.length);
    }

    public void clear() {
        topOfStack = -1;
    }

}
