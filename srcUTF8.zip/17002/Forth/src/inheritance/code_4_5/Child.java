package inheritance.code_4_5;
class Ancestor{
    Ancestor(){
        System.out.println("Ancestor.");
    }
}
class Parent extends Ancestor{
    Parent(){
        System.out.println("Parent.");
    }
}
public class Child  extends Parent{
    Child (){
        System.out.println ("Child.");
        
    }
public static void main(String[] args) {
    Child c=new Child ();
}
}
