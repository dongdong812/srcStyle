package inheritance.code_4_7;

public class Vehicle {
    String licenceNumber;
    public String getLicenceNumber() {
        return licenceNumber;
    }
public void setLicenceNumber(String licenceNumber) {
    this.licenceNumber=licenceNumber;
}
double area() {
    return 0;
}
}
