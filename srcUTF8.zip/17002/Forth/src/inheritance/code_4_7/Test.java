package inheritance.code_4_7;

public class Test {
      public static void main(String[] args) {
           Car a=new Car();
           Vehicle v=a;
           Car c=(Car) v;
           double x=c.width;
          double y=v.area();
      }
}
