package inheritance.code_4_17;

public interface Speakable {
    void speak();

}
