package inheritance.code_4_16;
public abstract class Vehicle{
    abstract public void horn();
}