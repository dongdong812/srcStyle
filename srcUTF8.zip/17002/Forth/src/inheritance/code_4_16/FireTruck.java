package inheritance.code_4_16;

public class FireTruck extends Vehicle{
    public void horn()
    {
        System.out.println("呜……");
    }
}