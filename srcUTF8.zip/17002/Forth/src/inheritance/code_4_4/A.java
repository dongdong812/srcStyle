package inheritance.code_4_4;

public class A {
    int member;

}
