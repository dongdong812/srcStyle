package inheritance.code_4_4;

public class Test {

    public static void main(String[] args) {
        A a=new A( ); 
    }
 
}
