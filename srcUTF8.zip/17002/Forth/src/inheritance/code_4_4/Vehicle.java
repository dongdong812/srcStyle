package inheritance.code_4_4;

public class Vehicle {
    String  licenceNUmber;
    public Vehicle (String licenceNumber) {
        this.licenceNUmber=licenceNumber;
    }

}
