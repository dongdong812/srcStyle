package inheritance.code_4_19;
class A {
    public void publicMember() {
        System.out.println("I am a public member in A.");
    }
    protected void protectedMember() {
        System.out.println("I am a default member in A.");
 }

void defaultMember() {
    System.out.println("I am a default member in A.");
}
private void privateMember() {
    System.out.println("I am a private member in A.");
}
void accessInClass()
{
    System.out.println("Access the membera in the same class:");
    publicMember();
    protectedMember();
    defaultMember();
    privateMember();
}

}
class B{
    void accessAbyOtherClass()
    {
        A a=new A();
        System.out.println("Accessed by other class in the same package:");
        a.publicMember();
        a.protectedMember();
        a.defaultMember();
    }
}
class C extends A{
    void accessAbySubClass() {
        System.out.println("Access the members  of A by subclass B in the same package:");
        publicMember();
        protectedMember();
        defaultMember();
        
    }
}
 
 
