package R;
import Q.A;

public class C extends A{
        void accessAbySubClass() {
            System.out.println("Access the members of A by subclass B in the same package:");
            publicMember();
            protectedMember();
            defaultMember();
            privateMember();
        }
}
