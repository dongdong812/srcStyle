 package Q;
public class A {
  public void publicMember()
  {
      System.out.println("I am a public member in A.");  
  }
  public void  protectedMember()
  {
      System.out.println("I am a protected member in A.");
      
  }
  public void defaultMember() {
      System.out.println("I am a default  member in A.");
  }
  
  public void  privateMember()
  {
      System.out.println("I am a private member in A.");
  }
  void accessAinClass() {
      System.out.println("Access the members in the same class:");
      publicMember();
      protectedMember();
      defaultMember();
      privateMember();
  }
  }