package exceptions.code_5_16;
import java.util.*;
public class Example {

    public static void main(String[] args) {
         Scanner scanner =new Scanner (System.in);
         while(true) {
             System.out.println("输入被除数、除数:");
             try {
                 int dividend=Integer.parseInt(scanner.next());
                 int divisor=Integer.parseInt(scanner.next());
                 int result=dividend/divisor;
                 System.out.println(dividend+"/"+divisor+"="+result);
             } catch(NumberFormatException  e)
             {
                 System.out.println("输入格式错误:"+e.getMessage());
             }catch(ArithmeticException e)
             {
                 System.out.println("数学运算异常，异常信息是:"+e.getMessage());
             }finally {
                 System.out.print ("继续吗(Y/N)?");
             }
         }

    }

}
