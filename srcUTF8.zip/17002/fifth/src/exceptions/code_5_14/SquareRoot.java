package exceptions.code_5_14;

import exceptions.code_5_13.OutOfRangeException;

public class SquareRoot {

    public static void main(String[] args) {
         double  c=-4;
         try {
          System.out.println(squareRoot(c));
         }catch(OutOfRangeException e) {
             System.out.println(e.getMessage()+e.getParameter());
         }

    }
static double squareRoot(double c)throws OutOfRangeException
{
    final double epsilon = 1e-15;
    if(c<0)
    {
        throw  new OutOfRangeException("负数不能求平方根:",c);
    }
    double  estimate=c;
    while (Math.abs(estimate-c/estimate)>epsilon*estimate)
    {
        estimate=(estimate+c/estimate)/2.0;
    }
    return estimate;
}
}
