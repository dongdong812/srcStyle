package exceptions.code_5_15;
public class Test {

    public static void main(String[] args) {
          Stack  s= new ArrayStack();
         Object item;
         try
         {
             item = s.pop();
             
         }catch(Exception e) {
             
             System.out.println(e.getMessage());
         }

    }

}
