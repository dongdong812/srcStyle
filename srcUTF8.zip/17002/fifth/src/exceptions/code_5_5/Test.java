package exceptions.code_5_5;
import  java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
public class Test {
    public String getNextLine() throws FileNotFoundException{
        Scanner sc=new Scanner (new File ("D:\\java\\test.txt"));
        return sc.next();
        
    }

}
